//File: hello.cpp
#include <iostream>
using namespace std;

int main(void) {
  cout << "Hello, World\n";
  cout << "Hello, Jenkins\n";
  cout << "I have successfully built and run\n";
  return 0;
}
